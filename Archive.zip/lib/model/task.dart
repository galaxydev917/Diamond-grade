class Task {
  int id;
  String text;
  bool favourite = false;
  bool completed = false;
}